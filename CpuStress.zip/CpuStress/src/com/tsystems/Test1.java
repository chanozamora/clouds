package com.tsystems;

public class Test1 {

	
	private  void spin(int milliseconds) {
	    long sleepTime = milliseconds*100000L; // convert to nanoseconds
	    long startTime = System.nanoTime();
	    while ((System.nanoTime() - startTime) < sleepTime) {}
	}
	
	private  void stress (){
		final int NUM_TESTS = 1000;
	    long start = System.nanoTime();
	    for (int i = 0; i < NUM_TESTS; i++) {
	        spin(500);
	    }
	    System.out.println("Took " + (System.nanoTime()-start)/1000000 +
	        "ms (expected " + (NUM_TESTS*500) + ")");
	}
	

	
	public static void main(String[] args) {
	    new Test1().stress();
	    new Test1().stress();
	    new Test1().stress();
	}
	
}
